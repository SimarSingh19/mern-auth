import sessionModel from "../models/session.model.js";

const CLEANUP_INTERVAL_MS = 30_000;

export function startSessionCleanup() {
    async function revokeExpiredSessions() {
        try {
            await sessionModel.updateMany(
                {revoked: false,expiresAt: { $lte: new Date() },},
                {$set: { revoked: true },}
            );
        } catch (error) {
            console.error("Session cleanup failed:", error.message);
        } finally {
            setTimeout(revokeExpiredSessions, CLEANUP_INTERVAL_MS);
        }
    }
    void revokeExpiredSessions();
}