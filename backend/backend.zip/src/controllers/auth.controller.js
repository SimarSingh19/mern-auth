import userModel from "../models/user.model.js";
import crypto from "crypto";
import jwt from "jsonwebtoken";
import config from "../config/config.js";
import sessionModel from "../models/session.model.js";
import { sendEmail } from "../services/email.service.js";
import {generateOtp, getOtpHtml} from "../utils/utils.js";
import otpModel from "../models/otp.model.js";
import bcrypt from "bcrypt";

async function getActiveSession(req) {
    const token = req.cookies?.accessToken;
    if (!token) {
        return null;
    }
    let decoded;

    try {
        decoded = jwt.verify(token, config.jwtSecret);
    } catch {
        return null;
    }

    const objectIdPattern = /^[a-fA-F0-9]{24}$/;

    if (!decoded || typeof decoded !== "object" || typeof decoded.id !== "string" || typeof decoded.sessionId !== "string" ||
        !objectIdPattern.test(decoded.id) || !objectIdPattern.test(decoded.sessionId)){
        return null;
    }

    return sessionModel.findOne({
        _id: decoded.sessionId,
        user: decoded.id,
        revoked: false,
        expiresAt: { $gt: new Date() },
    });
}

function clearAccessTokenCookie(res) {
    res.clearCookie("accessToken", {
        httpOnly: true,
        secure: process.env.NODE_ENV === "production",
        sameSite: "strict",
        path: "/api/auth",
    });
}

export async function register(req, res) {
    const { username, email, password } = req.body ?? {};

    if (typeof username !== "string" || typeof email !== "string" || typeof password !== "string" ||
        !username.trim() || !email.trim() || !password){
            return res.status(400).json({message: "Username, email, and password are required"})
    }

    if (password.length < 8 || Buffer.byteLength(password, "utf8") > 72){
        return res.status(400).json({message: "Password must be at least 8 characters and at most 72 bytes"});
    }

    const isAlreadyExists = await userModel.findOne({ $or: [{ username }, { email }] });
    if (isAlreadyExists) {
        return res.status(409).json({ message: "Username or email already exists" });
    }
    const hashedPassword = await bcrypt.hash(password, 12);

    const user = await userModel.create({ username, email, password: hashedPassword });

    const otp = generateOtp();
    const html = getOtpHtml(otp);
    const otpHash = crypto.createHash("sha256").update(otp).digest("hex");
    await otpModel.create({ email, user: user._id, otpHash });

    await sendEmail(email, "OTP Verification", `Your OTP is: ${otp}`, html);

    res.status(201).json({
        message: "User registered successfully",
        user: {username: user.username, email: user.email, verified: user.verified}
    });
}

export async function login(req, res) {
    const { email, password } = req.body ?? {};

    if (typeof email !== "string" || typeof password !== "string" || !email.trim() || !password){
        return res.status(400).json({message: "Valid email and password are required"});
    }

    const user = await userModel.findOne({ email });
    if (!user) {
        return res.status(401).json({ message: "Invalid email or password" });
    }

    if (!user.verified) {
        return res.status(401).json({ message: "Please verify your email" });
    }

    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) {
        return res.status(401).json({ message: "Invalid email or password" });
    }

    const expiresAtSeconds = Math.floor(Date.now() / 1000) + 1 * 60;
    const expiresAt = new Date(expiresAtSeconds * 1000);

    const session = await sessionModel.create({
        user: user._id,
        ipAddress: req.ip,
        userAgent: req.headers["user-agent"],
        expiresAt: expiresAt,
    });

    const accessToken = jwt.sign(
        { id: user._id, sessionId: session._id, exp: expiresAtSeconds },
        config.jwtSecret,
    );

    res.cookie("accessToken", accessToken, {
        httpOnly: true,
        secure: process.env.NODE_ENV === "production",
        sameSite: "strict",
        path: "/api/auth",
        expires: expiresAt,
    });

    res.status(200).json({ message: "Login successful", expiresAt, user: {
        id: user._id,
        username: user.username,
        email: user.email,
        verified: user.verified
    }});
}

export async function getMe(req, res) {
    if (!req.cookies?.accessToken) {
        return res.status(204).end();
    }

    const session = await getActiveSession(req);
    if (!session) {
        return res.status(401).json({message: "Session expired. Please log in again.",});
    }

    const user = await userModel.findById(session.user);
    if (!user) {
        return res.status(401).json({message: "User no longer exists."});
    }

    return res.status(200).json({
        message: "User found",
        user: {
            id: user._id,
            username: user.username,
            email: user.email,
            verified: user.verified,
        },
        expiresAt: session.expiresAt,
    });
}

export async function logout(req, res) {
    const session = await getActiveSession(req);
    if (!session) {
        clearAccessTokenCookie(res);
        return res.status(401).json({message: "Session expired. Please log in again."});
    }

    await sessionModel.updateOne(
        { _id: session._id },
        { $set: { revoked: true } }
    );

    clearAccessTokenCookie(res);
    return res.status(200).json({message: "Logout successful"});
}

export async function logoutAll(req, res) {
    const session = await getActiveSession(req);
    if (!session) {
        clearAccessTokenCookie(res);
        return res.status(401).json({message: "Session expired. Please log in again."});
    }

    await sessionModel.updateMany(
        { user: session.user, revoked: false },
        { $set: { revoked: true } }
    );

    clearAccessTokenCookie(res);
    return res.status(200).json({message: "Logout from all sessions successful"});
}

export async function verifyEmail(req, res) {
    const { email, otp } = req.body;
    if (!email || !otp) {
        return res.status(400).json({ message: "Email and OTP are required" });
    }

    try {
        const otpHash = crypto.createHash("sha256").update(otp).digest("hex");
        const otpDoc = await otpModel.findOne({email,otpHash,expiresAt: { $gt: new Date() }});
        if (!otpDoc) {
            return res.status(400).json({message: "Invalid or expired OTP"});
        }

        // const user = await userModel.findByIdAndUpdate(otpDoc.user,{ verified: true });

        const user = await userModel.findByIdAndUpdate(otpDoc.user,
            {$set: {verified: true}},{returnDocument:"after"}
        );

        if (!user) {
            return res.status(404).json({message: "User not found"});
        }

        await otpModel.deleteMany({user: otpDoc.user});

        res.status(200).json({ message: "Email verified successfully", user:{
            username: user.username,
            email: user.email,
            verified: user.verified
        } });
    } catch (error) {
        console.log(error);
        res.status(500).json({ message: "Internal server error" });
    }
}