import express from "express";
import morgan from "morgan";
import authRouter from "./routes/auth.routes.js";
import cookieParser from "cookie-parser";

const app = express();
app.use(express.json());

app.use(morgan("dev"));
app.use(cookieParser());

app.use("/api/auth", authRouter);

app.use((error, req, res, next) => {
    if (res.headersSent) {
        return next(error);
    }
    if (error.code === 11000) {
        return res.status(409).json({message: "Username or email already exists"});
    }
    if (error.name === "ValidationError") {
        return res.status(400).json({message: "Please check the submitted fields"});
    }
    if (error.type === "entity.parse.failed") {
        return res.status(400).json({message: "Invalid JSON body"});
    }
    console.error(error);
    return res.status(500).json({message: "Something went wrong"});
});

export default app;